using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;
using IEML.Core.Contracts;
using IEML.Core.Models;
using IEML.Core.Services;
namespace IEML.App;

public partial class DownloadStageControl : UserControl
{
    readonly IInstanceService _instances;
    readonly IModrinthService _modrinth;
    readonly CurseForgeService _curseForge;
    readonly ObservableCollection<ContentHit> _results = new();

    /// 在「遊戲」分頁建立了新實例（宿主可據此重新整理主畫面的實例清單）。
    public event Action? InstanceCreated;

    public DownloadStageControl(IInstanceService instances)
    {
        InitializeComponent();
        _instances = instances;
        _modrinth = new ModrinthService(instances);
        _curseForge = new CurseForgeService(instances);
        ResultsList.ItemsSource = _results;
        GamePanel.Initialize(instances);
        GamePanel.InstanceCreated += () => { InstanceCreated?.Invoke(); _ = LoadInstancesAsync(); };
        Loaded += async (_, _) => await LoadInstancesAsync();
        InitDetail();
    }

    async Task LoadInstancesAsync()
    {
        var instances = await _instances.ListAsync();
        InstanceBox.ItemsSource = instances;
        InstanceBox.SelectedIndex = 0;
        TargetBox.ItemsSource = instances;
        TargetBox.SelectedItem = InstanceBox.SelectedItem;
    }

    /// 地圖：開啟地圖視窗（匯入 zip／資料夾／網址、CurseForge 地圖、備份、刪除），放進「安裝到實例」選的實例。
    void Maps_Click(object sender, RoutedEventArgs e)
    {
        if (InstanceBox.SelectedItem is not InstanceConfig inst)
        {
            _ = Dialogs.InfoAsync("地圖", "請先建立一個實例，並在「內容」分頁的「安裝到」選好（地圖會放進該實例的 saves 資料夾）。");
            return;
        }
        (Window.GetWindow(this) as MainWindow)?.ShowPage("地圖管理", "匯入、備份與瀏覽地圖", new MapsPage(_instances, inst));
    }

    void Tab_Click(object sender, RoutedEventArgs e)
    {
        var tag = (sender as FrameworkElement)?.Tag as string;
        var tab = tag;
        GamePanel.Visibility = tab == "game" ? Visibility.Visible : Visibility.Collapsed;
        ContentPanel.Visibility = tab == "content" ? Visibility.Visible : Visibility.Collapsed;
        GameTab.Opacity = tab == "game" ? 1 : .55;
        ContentTab.Opacity = tab == "content" ? 1 : .55;
    }

    async void Search_Click(object sender, RoutedEventArgs e)
    {
        _results.Clear();
        ContentStatus.Text = "搜尋中…";
        try
        {
            var kind = GetKind();
            var sort = (SortBox.SelectedItem as ComboBoxItem)?.Tag as string ?? "relevance";
            var category = (CategoryBox.SelectedItem as FilterOption)?.Id;
            var loader = (LoaderFilterBox.SelectedItem as FilterOption)?.Id;
            var env = (EnvBox.SelectedItem as ComboBoxItem)?.Tag as string;
            var mc = string.IsNullOrWhiteSpace(FilterMcBox.Text) ? null : FilterMcBox.Text.Trim();
            var source = (SourceBox.SelectedItem as ComboBoxItem)?.Tag as string ?? "Modrinth";
            if (source == "CurseForge")
            {
                var inst = InstanceBox.SelectedItem as InstanceConfig;
                var cfLoader = inst?.Loader;
                var hits = await _curseForge.SearchAsync(QueryBox.Text.Trim(), kind, mc ?? "", cfLoader);
                foreach (var hit in hits) _results.Add(hit);
                ContentStatus.Text = $"CurseForge：已顯示 {_results.Count} 個結果";
                return;
            }

            var result = await _modrinth.SearchAsync(new ModrinthQuery(QueryBox.Text.Trim(), kind, mc, loader, category, env, sort, 0, 20));
            foreach (var hit in result.Hits) _results.Add(hit);
            ContentStatus.Text = $"共 {result.Total} 個結果，已顯示 {_results.Count} 個（點一個項目看所有版本）";
        }
        catch (Exception ex) { ContentStatus.Text = "搜尋失敗：" + ex.Message; }
    }

    async void InstallHit_Click(object sender, RoutedEventArgs e)
    {
        if ((sender as FrameworkElement)?.Tag is not ContentHit hit) return;
        ContentStatus.Text = $"安裝中：{hit.Title}";
        try
        {
            var source = (SourceBox.SelectedItem as ComboBoxItem)?.Tag as string ?? "Modrinth";
            if (source == "CurseForge")
            {
                var inst = InstanceBox.SelectedItem as InstanceConfig;
                if (hit.Kind == ContentKind.Modpack)
                    await _curseForge.InstallModpackAsync(hit.ProjectId);
                else
                {
                    if (inst is null) throw new InvalidOperationException("請先建立或選擇安裝目標實例");
                    await _curseForge.InstallFileAsync(inst.Id, hit.ProjectId, hit.Kind);
                }
            }
            else if (hit.Kind == ContentKind.Modpack)
            {
                await _modrinth.InstallModpackAsync(hit.ProjectId);
            }
            else
            {
                var inst = InstanceBox.SelectedItem as InstanceConfig;
                if (inst is null) throw new InvalidOperationException("請先建立或選擇安裝目標實例");
                await _modrinth.InstallAsync(inst.Id, hit.ProjectId, hit.Kind);
            }
            ContentStatus.Text = hit.Kind == ContentKind.Modpack ? $"已建立整合包實例：{hit.Title}" : $"已安裝：{hit.Title}";
        }
        catch (Exception ex) { ContentStatus.Text = "安裝失敗：" + ex.Message; }
    }

    async void KindChanged(object sender, SelectionChangedEventArgs e)
    {
        if (!IsLoaded) return;
        await RefreshFiltersAsync();
    }

    void FiltersChanged(object sender, SelectionChangedEventArgs e) { }

    async Task RefreshFiltersAsync()
    {
        try
        {
            var kind = GetKind();
            var categories = await _modrinth.GetCategoriesAsync(kind);
            CategoryBox.ItemsSource = new[] { new FilterOption("", "全部分類") }.Concat(categories).ToList();
            CategoryBox.DisplayMemberPath = "Name";
            CategoryBox.SelectedValuePath = "Id";
            CategoryBox.SelectedIndex = 0;

            var loaders = await _modrinth.GetLoadersAsync(kind);
            LoaderFilterBox.ItemsSource = new[] { new FilterOption("", "全部載入器") }.Concat(loaders).ToList();
            LoaderFilterBox.DisplayMemberPath = "Name";
            LoaderFilterBox.SelectedValuePath = "Id";
            LoaderFilterBox.SelectedIndex = 0;

            FilterMcBox.ItemsSource = new[] { "", "1.21.1", "1.21", "1.20.6", "1.20.4", "1.20.1", "1.19.4", "1.18.2", "1.16.5", "1.12.2", "1.8.9" };
            if (InstanceBox.SelectedItem is InstanceConfig inst) FilterMcBox.Text = inst.McVersion;
        }
        catch (Exception ex) { ContentStatus.Text = "載入篩選失敗：" + ex.Message; }
    }

    ContentKind GetKind() => ((KindBox.SelectedItem as ComboBoxItem)?.Tag as string) switch
    {
        "Shader" => ContentKind.Shader,
        "ResourcePack" => ContentKind.ResourcePack,
        "Modpack" => ContentKind.Modpack,
        _ => ContentKind.Mod
    };

    async void ImportLocal_Click(object sender, RoutedEventArgs e)
    {
        var dlg = new Microsoft.Win32.OpenFileDialog
        {
            Title = "選擇本機整合包",
            Filter = "整合包 (*.zip;*.mrpack)|*.zip;*.mrpack|所有檔案 (*.*)|*.*"
        };
        if (dlg.ShowDialog() != true) return;
        try
        {
            var cf = new CurseForgeService(_instances);
            var modrinth = new ModrinthService(_instances);
            if (dlg.FileName.EndsWith(".mrpack", StringComparison.OrdinalIgnoreCase))
            {
                await modrinth.ImportMrpackAsync(dlg.FileName, System.IO.Path.GetFileNameWithoutExtension(dlg.FileName), default);
            }
            else
            {
                await cf.ImportLocalAsync(dlg.FileName);
            }
            _ = Dialogs.InfoAsync("匯入整合包", "本機整合包匯入完成，已加入實例清單。");
            await LoadInstancesAsync();
        }
        catch (Exception ex) { _ = Dialogs.InfoAsync("匯入整合包", "匯入失敗：" + ex.Message); }
    }
}
